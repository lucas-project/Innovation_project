import React from "react";

const Ailis = () => {
    return (

        <div style={{ position: "absolute", marginTop: "70px", fontSize: "20px" }}>
            <br/><br/>Ailis
        </div>
    );
};

export default Ailis;