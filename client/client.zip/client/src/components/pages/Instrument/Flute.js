import React from "react";

const Flute = () => {
    return (

        <div style={{ position: "absolute", marginTop: "70px", fontSize: "20px" }}>
            <br/><br/>Flute
        </div>
    );
};

export default Flute;