import React from "react";

const Profile = () => {
    return (

        <div style={{ position: "absolute", marginTop: "70px", fontSize: "20px" }}>
            <br/><br/>Profile
        </div>
    );
};

export default Profile;